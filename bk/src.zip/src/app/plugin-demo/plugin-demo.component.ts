import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plugin-demo',
  templateUrl: './plugin-demo.component.html',
  styleUrls: ['./plugin-demo.component.scss']
})
export class PluginDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
